const formulario=document.querySelector("#formulario");
const campoTitulo=document.querySelector("#titulo");
const campoCliente=document.querySelector("#cliente");
const campoPrioridade=document.querySelector("#prioridade");
const listaChamados=document.querySelector("#lista-chamados");
const filtro=document.querySelector("#filtro");
const erroTitulo=document.querySelector("#erro-titulo");
const mensagemVazia=document.querySelector("#sem-chamados");
let chamados=[];
try{chamados=JSON.parse(localStorage.getItem("chamados"))||[];if(!Array.isArray(chamados))chamados=[]}catch(erro){chamados=[]}
function salvarChamados(){localStorage.setItem("chamados",JSON.stringify(chamados))}
function validarTitulo(titulo){const texto=titulo.trim();return texto.length>=3&&texto.length<=80}
function concluirChamado(id){chamados=chamados.map(chamado=>chamado.id===id?{...chamado,status:"concluido"}:chamado);salvarChamados();mostrarChamados()}
function mostrarChamados(){
listaChamados.textContent="";
const statusFiltro=filtro.value;
const filtrados=chamados.filter(chamado=>statusFiltro==="todos"||chamado.status===statusFiltro);
mensagemVazia.hidden=filtrados.length!==0;
filtrados.forEach(chamado=>{
const cartao=document.createElement("article");cartao.className="cartao";
const status=document.createElement("span");status.className=`status ${chamado.status}`;status.textContent=chamado.status==="aberto"?"Aberto":"Concluído";
const titulo=document.createElement("h3");titulo.textContent=chamado.titulo;
const cliente=document.createElement("p");cliente.textContent=`Cliente: ${chamado.cliente}`;
const prioridade=document.createElement("p");prioridade.textContent=`Prioridade: ${chamado.prioridade}`;
cartao.append(status,titulo,cliente,prioridade);
if(chamado.status==="aberto"){const botao=document.createElement("button");botao.type="button";botao.textContent="Concluir";botao.addEventListener("click",()=>concluirChamado(chamado.id));cartao.appendChild(botao)}
listaChamados.appendChild(cartao);
});
}
formulario.addEventListener("submit",ev=>{
ev.preventDefault();const titulo=campoTitulo.value.trim();
if(!validarTitulo(titulo)){erroTitulo.textContent="O título deve ter entre 3 e 80 caracteres.";campoTitulo.setAttribute("aria-invalid","true");campoTitulo.focus();return}
erroTitulo.textContent="";campoTitulo.removeAttribute("aria-invalid");
chamados.push({id:Date.now(),titulo,cliente:campoCliente.value.trim(),prioridade:campoPrioridade.value,status:"aberto"});
salvarChamados();mostrarChamados();formulario.reset();campoTitulo.focus();
});
filtro.addEventListener("change",mostrarChamados);
mostrarChamados();
