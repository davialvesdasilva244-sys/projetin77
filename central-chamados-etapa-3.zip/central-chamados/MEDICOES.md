# MEDIÇÕES — CENTRAL DE CHAMADOS

## 1. Identificação
- Projeto: Central de Chamados
- Etapa: 3/3
- Dispositivo do Lighthouse: Mobile
- URL publicada: PREENCHER APÓS PUBLICAÇÃO

## 2. Lighthouse — antes das melhorias
Registre somente notas medidas de verdade. Se não houver medição anterior, mantenha "não medido".

| Indicador | Antes |
|---|---:|
| Performance | Não medido |
| Accessibility | Não medido |
| Best Practices | Não medido |
| SEO | Não medido |

## 3. Lighthouse — depois das melhorias
| Indicador | Depois |
|---|---:|
| Performance | A preencher |
| Accessibility | A preencher |
| Best Practices | A preencher |
| SEO | A preencher |

## 4. Validação W3C
- HTML: Aguardando https://validator.w3.org/
- CSS: Aguardando https://jigsaw.w3.org/css-validator/
- Erros encontrados: A preencher
- Correções realizadas: A preencher

## 5. Melhorias realizadas
- Título e meta description próprios.
- URL canonical e metadados Open Graph.
- Um único h1.
- robots.txt e sitemap.xml.
- Caminhos relativos para CSS e JavaScript.
- Layout responsivo.
- Chamados salvos em Local Storage usando JSON.
- Validação do título e mensagens de erro acessíveis.

## 6. Publicação
- Repositório GitHub: A preencher
- GitHub Pages: A preencher
- Data da publicação: A preencher

## 7. Conclusão
As notas finais devem ser preenchidas após executar o Lighthouse e os validadores W3C. Compare medições feitas nas mesmas condições.
